package tests;

import io.quarkus.test.junit.QuarkusTest;
import org.acme.fleet.Fleet;
import org.acme.fleet.Equipment;
import org.acme.fleet.equipment.BatteryVoltage;
import org.acme.fleet.equipment.EquipmentHeader;
import org.acme.fleet.equipment.FuelLevel;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

@QuarkusTest
public class FleetTests {

    @Test
    public void testGetAvgFuelLevel() {

        List<Equipment> equipments = new ArrayList<>();

        for(int k = 1; k < 501; k++) {
            FuelLevel fuelLevel = new FuelLevel(String.valueOf(k), "");
            Equipment equipment = new Equipment(
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    fuelLevel,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null
            );
            equipments.add(equipment);
        }

        Fleet fleet = new Fleet("", equipments, null);

        Assertions.assertEquals(250.5, fleet.getAvgFuelLevel());
    }

    @Test
    public void testGetAvgFuelLevel2() {
        List<Equipment> equipments = new ArrayList<>();

        for(int k = 0; k < 10; k++) {
            Equipment equipment = new Equipment(
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    new FuelLevel(null, null),
                    null,
                    null,
                    null,
                    null,
                    null,
                    null
            );
            equipments.add(equipment);
        }

        Fleet fleet = new Fleet("", equipments, null);

        Assertions.assertEquals(-1, fleet.getAvgFuelLevel());
    }

    @Test
    public void testGetAvgFuelLevel3() {
        List<Equipment> equipments = new ArrayList<>();

        for(int k = 0; k < 10; k++) {
            Equipment equipment = new Equipment(
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    new FuelLevel("", null),
                    null,
                    null,
                    null,
                    null,
                    null,
                    null
            );
            equipments.add(equipment);
        }

        Fleet fleet = new Fleet("", equipments, null);

        Assertions.assertEquals(-1, fleet.getAvgFuelLevel());
    }

    @Test
    public void testGetAvgBatteryV() {

        List<Equipment> equipments = new ArrayList<>();

        for(int k = 1; k < 501; k++) {
            BatteryVoltage batteryVoltage = new BatteryVoltage(String.valueOf(k), "", "");
            Equipment equipment = new Equipment(
                    null,
                    batteryVoltage,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null
            );
            equipments.add(equipment);
        }

        Fleet fleet = new Fleet("", equipments, null);

        Assertions.assertEquals(250.5, fleet.getAvgBatteryV());
    }

    @Test
    public void testGetAvgBatteryV2() {
        List<Equipment> equipments = new ArrayList<>();

        for(int k = 0; k < 10; k++) {
            Equipment equipment = new Equipment(
                    null,
                    new BatteryVoltage(null, "", ""),
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    new FuelLevel(null, null),
                    null,
                    null,
                    null,
                    null,
                    null,
                    null
            );
            equipments.add(equipment);
        }

        Fleet fleet = new Fleet("", equipments, null);

        Assertions.assertEquals(-1, fleet.getAvgBatteryV());
    }

    @Test
    public void testGetAvgBatteryV3() {
        List<Equipment> equipments = new ArrayList<>();

        for(int k = 0; k < 10; k++) {
            Equipment equipment = new Equipment(
                    null,
                    new BatteryVoltage("", "", ""),
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    new FuelLevel(null, null),
                    null,
                    null,
                    null,
                    null,
                    null,
                    null
            );
            equipments.add(equipment);
        }

        Fleet fleet = new Fleet("", equipments, null);

        Assertions.assertEquals(-1, fleet.getAvgBatteryV());
    }

    @Test
    public void testGetFleetSize() {
        List<Equipment> equipments = new ArrayList<>();

        for(int k = 0; k < 500; k++) {
            EquipmentHeader equipmentHeader = new EquipmentHeader(
                    null,
                    null,
                    null,
                    String.valueOf(k),
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null
            );
            Equipment equipment = new Equipment(
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    equipmentHeader,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null
            );
            equipments.add(equipment);
        }

        Fleet fleet = new Fleet("", equipments, null);

        Assertions.assertEquals(500, fleet.getFleetSize());
    }

    @Test
    public void testGetFleetSize2() {
        List<Equipment> equipments = new ArrayList<>();

        for(int i = 0; i < 10; i++) {
            for (int k = 0; k < 500; k++) {
                EquipmentHeader equipmentHeader = new EquipmentHeader(
                        null,
                        null,
                        null,
                        String.valueOf(k),
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null
                );
                Equipment equipment = new Equipment(
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        equipmentHeader,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null
                );
                equipments.add(equipment);
            }
        }

        Fleet fleet = new Fleet("", equipments, null);

        Assertions.assertEquals(500, fleet.getFleetSize());
    }

    @Test
    public void testGetOlderMachine2() {
        List<Equipment> equipments = new ArrayList<>();

        List<OffsetDateTime> dates = new ArrayList<>();
        for(int k = 0; k < 500; k++) {
            dates.add(OffsetDateTime.now());
            EquipmentHeader equipmentHeader = new EquipmentHeader(
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    String.valueOf(dates.get(k)),
                    null,
                    null
            );
            Equipment equipment = new Equipment(
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    equipmentHeader,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null
            );
            equipments.add(equipment);
        }

        Fleet fleet = new Fleet("", equipments, null);

        Assertions.assertEquals(String.valueOf(dates.get(0)), String.valueOf(fleet.getOldestMachine()));
    }

    @Test
    public void testGetOlderMachine() {
        List<Equipment> equipments = new ArrayList<>();

        for(int k = 0; k < 500; k++) {
            EquipmentHeader equipmentHeader = new EquipmentHeader(
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    "2020-08-19T15:08:15.0000000+00:00",
                    null,
                    null
            );
            Equipment equipment = new Equipment(
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    equipmentHeader,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null
            );
            equipments.add(equipment);
        }

        Fleet fleet = new Fleet("", equipments, null);

        Assertions.assertEquals("2020-08-19T15:08:15Z", String.valueOf(fleet.getOldestMachine()));
    }
}

