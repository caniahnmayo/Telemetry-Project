package tests;

import org.acme.fleet.equipment.FuelLevel;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import io.quarkus.test.junit.QuarkusTest;

@QuarkusTest
public class FuelLevelTests {

    @Test
    public void testFuelLevelCommonizer() {
        FuelLevel fuelLevel = new FuelLevel("error", "");
        Assertions.assertEquals("0", fuelLevel.FuelLevel);

        fuelLevel = new FuelLevel("full", "");
        Assertions.assertEquals("100", fuelLevel.FuelLevel);

        fuelLevel = new FuelLevel("high", "");
        Assertions.assertEquals("80", fuelLevel.FuelLevel);

        fuelLevel = new FuelLevel("high-level", "");
        Assertions.assertEquals("80", fuelLevel.FuelLevel);

        fuelLevel = new FuelLevel("low-level", "");
        Assertions.assertEquals("20", fuelLevel.FuelLevel);

        fuelLevel = new FuelLevel("low", "");
        Assertions.assertEquals("20", fuelLevel.FuelLevel);

        fuelLevel = new FuelLevel("medium", "");
        Assertions.assertEquals("50", fuelLevel.FuelLevel);

        fuelLevel = new FuelLevel("mid", "");
        Assertions.assertEquals("50", fuelLevel.FuelLevel);

        fuelLevel = new FuelLevel("mid-level", "");
        Assertions.assertEquals("50", fuelLevel.FuelLevel);

        fuelLevel = new FuelLevel("3/4", "");
        Assertions.assertEquals("0.75", fuelLevel.FuelLevel);

        fuelLevel = new FuelLevel("0.58", "");
        Assertions.assertEquals("0.58", fuelLevel.FuelLevel);
    }
}
