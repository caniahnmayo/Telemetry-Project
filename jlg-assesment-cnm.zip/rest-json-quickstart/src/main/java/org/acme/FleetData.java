package org.acme;

import org.acme.fleet.Fleet;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class FleetData {

    @com.fasterxml.jackson.annotation.JsonProperty("Fleet")
    public Fleet Fleet;

    FleetData() {}

    FleetData(Fleet Fleet) {
        this.Fleet = Fleet;
    }
}
