package org.acme;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import org.jboss.resteasy.reactive.PartType;
import org.jboss.resteasy.reactive.RestForm;


import java.util.*;

@Path("/fleet")
public class FleetResource {

    private Set<FleetData> fleetData = Collections.synchronizedSet(new LinkedHashSet<>());
    public FleetResource() {}

    @GET
    @Produces(MediaType.TEXT_HTML)
    public String list() {
        List<String> data = new ArrayList<>();
        for (FleetData fleet : fleetData) {
            data.add(String.valueOf(fleet.Fleet.getFleetSize()));
            data.add(String.valueOf(fleet.Fleet.getAvgFuelLevel()));
            data.add(String.valueOf(fleet.Fleet.getAvgBatteryV()));
            data.add(String.valueOf(fleet.Fleet.getOldestMachine()));
        }
        data.add(String.valueOf(fleetData.size()));
        return data + "\n";
    }

    @POST
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    public void upload(@RestForm("file") @PartType(MediaType.APPLICATION_JSON) List<FleetData> incoming) {
        fleetData.addAll(incoming);
    }
}
