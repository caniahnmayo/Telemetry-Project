package org.acme.fleet.equipment;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class Location {

    public String GpsAccuracy;
    public String GsmStrength;
    public String Latitude;
    public String Longitude;
    public String datetime;

    Location() {}

    Location(String GpsAccuracy, String GsmStrength, String Latitude, String Longitude, String datetime) {
        this.GpsAccuracy = GpsAccuracy;
        this.GsmStrength = GsmStrength;
        this.Latitude = Latitude;
        this.Longitude = Longitude;
        this.datetime = datetime;
    }
}
