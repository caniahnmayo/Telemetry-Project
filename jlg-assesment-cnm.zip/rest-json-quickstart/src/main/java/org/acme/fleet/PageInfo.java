package org.acme.fleet;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class PageInfo {

    public String HasNext;
    public String NextPageNo;
    public String PageSize;
    public String RecordsCount;

    PageInfo(){}

    PageInfo(String HasNext, String NextPageNo, String PageSize, String RecordsCount) {
        this.HasNext = HasNext;
        this.NextPageNo = NextPageNo;
        this.PageSize = PageSize;
        this.RecordsCount = RecordsCount;
    }
}
