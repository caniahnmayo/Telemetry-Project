package org.acme.fleet.equipment.machine;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class GroundModeSelected {

    public String Value;
    public String datetime;

    GroundModeSelected() {}

    public GroundModeSelected(String Value, String datetime) {
        this.Value = Value;
        this.datetime = datetime;
    }
}
