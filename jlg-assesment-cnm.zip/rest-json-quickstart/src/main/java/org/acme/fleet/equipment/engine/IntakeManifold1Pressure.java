package org.acme.fleet.equipment.engine;

public class IntakeManifold1Pressure {

    public String Pressure;
    public String UnitOfMeasure;
    public String datetime;

    IntakeManifold1Pressure() {}

    IntakeManifold1Pressure(String pressure, String unitOfMeasure, String datetime) {
        this.Pressure = pressure;
        this.UnitOfMeasure = unitOfMeasure;
        this.datetime = datetime;
    }
}
