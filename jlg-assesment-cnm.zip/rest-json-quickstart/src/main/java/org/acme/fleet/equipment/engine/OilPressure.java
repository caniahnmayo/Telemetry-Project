package org.acme.fleet.equipment.engine;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class OilPressure {

    public String Pressure;
    public String UnitOfMeasure;
    public String datetime;

    OilPressure() {}

    OilPressure(String Pressure, String UnitOfMeasure, String datetime) {
        this.Pressure = Pressure;
        this.UnitOfMeasure = UnitOfMeasure;
        this.datetime = datetime;
    }
}
