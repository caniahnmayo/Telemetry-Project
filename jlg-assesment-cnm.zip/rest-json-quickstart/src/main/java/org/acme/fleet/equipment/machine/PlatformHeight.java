package org.acme.fleet.equipment.machine;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class PlatformHeight {

    public String Height;

    @com.fasterxml.jackson.annotation.JsonProperty("Histogram Summary")
    public String HistogramSummary;

    public String UnitOfMeasure;
    public String datetime;

    PlatformHeight() {}

    PlatformHeight(String Height, String HistogramSummary, String UnitOfMeasure, String datetime) {
        this.Height = Height;
        this.HistogramSummary = HistogramSummary;
        this.UnitOfMeasure = UnitOfMeasure;
        this.datetime = datetime;
    }
}
