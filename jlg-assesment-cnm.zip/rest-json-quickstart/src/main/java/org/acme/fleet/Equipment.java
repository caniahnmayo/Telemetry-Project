package org.acme.fleet;
;
import org.acme.fleet.equipment.*;

import java.util.List;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class Equipment {

    public Aftertreatment Aftertreatment;
    public BatteryVoltage BatteryVoltage;
    public Charger Charger;
    public CumulativeOperatingHours CumulativeOperatingHours;
    public DeviceBattery DeviceBattery;
    public List<DiagnosticTroubleCode> DiagnosticTroubleCode;
    public Engine Engine;
    public EquipmentHeader EquipmentHeader;
    public FuelLevel FuelLevel;
    public IgnitionStatus IgnitionStatus;
    public Location Location;
    public Machine Machine;
    public MachineSoftwareVersion MachineSoftwareVersion;
    public StateOfCharge StateOfCharge;

    @com.fasterxml.jackson.annotation.JsonProperty("Parameter Changed")
    public ParameterChanged ParameterChanged;

    Equipment() {}

    public Equipment(
            Aftertreatment Aftertreatment,
            BatteryVoltage BatteryVoltage,
            Charger Charger,
            CumulativeOperatingHours CumulativeOperatingHours,
            DeviceBattery DeviceBattery,
            List<DiagnosticTroubleCode> DiagnosticTroubleCode,
            Engine Engine,
            EquipmentHeader EquipmentHeader,
            FuelLevel FuelLevel,
            IgnitionStatus IgnitionStatus,
            Location Location,
            Machine Machine,
            MachineSoftwareVersion MachineSoftwareVersion,
            ParameterChanged ParameterChanged,
            StateOfCharge StateOfCharge
    ) {
        this.Aftertreatment = Aftertreatment;
        this.BatteryVoltage = BatteryVoltage;
        this.Charger = Charger;
        this.CumulativeOperatingHours = CumulativeOperatingHours;
        this.DeviceBattery = DeviceBattery;
        this.DiagnosticTroubleCode = DiagnosticTroubleCode;
        this.Engine = Engine;
        this.EquipmentHeader = EquipmentHeader;
        this.FuelLevel = FuelLevel;
        this.IgnitionStatus = IgnitionStatus;
        this.Location = Location;
        this.Machine = Machine;
        this.MachineSoftwareVersion = MachineSoftwareVersion;
        this.ParameterChanged = ParameterChanged;
        this.StateOfCharge = StateOfCharge;
    }
}
