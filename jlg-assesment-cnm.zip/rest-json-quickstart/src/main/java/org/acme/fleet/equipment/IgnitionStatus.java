package org.acme.fleet.equipment;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class IgnitionStatus {

    public String Running;
    public String Status;
    public String datetime;

    IgnitionStatus(){}

    IgnitionStatus(String Running, String Status, String datetime) {
        this.Running = Running;
        this.Status = Status;
        this.datetime = datetime;
    }
}
