package org.acme.fleet.equipment;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class BatteryVoltage {

    public String BatteryReading;
    public String UnitOfMeasure;
    public String datetime;

    BatteryVoltage() {}

    public BatteryVoltage(String BatteryReading, String UnitOfMeasure, String datetime) {
        this.BatteryReading = BatteryReading;
        this.UnitOfMeasure = UnitOfMeasure;
        this.datetime = datetime;
    }
}
