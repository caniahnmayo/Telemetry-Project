package org.acme.fleet.equipment;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class CumulativeOperatingHours {

    public String Hour;
    public String datetime;

    CumulativeOperatingHours() {}

    CumulativeOperatingHours(String Hour, String datetime) {
        this.Hour = Hour;
        this.datetime = datetime;
    }
}
