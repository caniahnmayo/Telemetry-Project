package org.acme.fleet.equipment.engine;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class ActualTorque {

    public String Torque;
    public String UnitOfMeasure;
    public String datetime;

    ActualTorque() {}

    ActualTorque(String Torque, String UnitOfMeasure, String datetime) {
        this.Torque = Torque;
        this.UnitOfMeasure = UnitOfMeasure;
        this.datetime = datetime;
    }
}
