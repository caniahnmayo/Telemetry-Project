package org.acme.fleet.equipment.engine;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class FuelDeliveryPressure {

    public String Pressure;
    public String UnitOfMeasure;
    public String datetime;

    FuelDeliveryPressure() {}

    FuelDeliveryPressure(String pressure, String unitOfMeasure, String datetime) {
        this.Pressure = pressure;
        this.UnitOfMeasure = unitOfMeasure;
        this.datetime = datetime;
    }
}
