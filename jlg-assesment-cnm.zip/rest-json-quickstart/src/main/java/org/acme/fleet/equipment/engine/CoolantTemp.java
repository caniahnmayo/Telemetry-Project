package org.acme.fleet.equipment.engine;

public class CoolantTemp {

    public String Temperature;
    public String UnitOfMeasure;
    public String datetime;

    public CoolantTemp() {}

    public CoolantTemp(String Temperature, String UnitOfMeasure, String datetime) {
        this.Temperature = Temperature;
        this.UnitOfMeasure = UnitOfMeasure;
        this.datetime = datetime;
    }
}
