package org.acme.fleet.equipment;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class MachineSoftwareVersion {

    public String version;
    public String dateTime;

    MachineSoftwareVersion() {}

    MachineSoftwareVersion(String version, String dateTime) {
        this.version = version;
        this.dateTime = dateTime;
    }
}
