package org.acme.fleet.equipment.engine;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class FuelUsed {

    public String FuelConsumed;
    public String FuelUnits;
    public String datetime;

    FuelUsed() {}

    FuelUsed(String FuelConsumed, String FuelUnits, String datetime) {
        this.FuelConsumed = FuelConsumed;
        this.FuelUnits = FuelUnits;
        this.datetime = datetime;
    }
}
