package org.acme.fleet.equipment.engine;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class RequestedSpeedLimit {

    public String Speed;
    public String UnitOfMeasure;
    public String datetime;

    public RequestedSpeedLimit() {}

    public RequestedSpeedLimit(String Speed, String UnitOfMeasure, String datetime) {
        this.Speed = Speed;
        this.UnitOfMeasure = UnitOfMeasure;
        this.datetime = datetime;
    }
}
