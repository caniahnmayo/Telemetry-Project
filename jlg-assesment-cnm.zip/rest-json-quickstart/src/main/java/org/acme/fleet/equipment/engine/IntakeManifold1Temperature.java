package org.acme.fleet.equipment.engine;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class IntakeManifold1Temperature {

    public String Temperature;
    public String UnitOfMeasure;
    public String datetime;

    IntakeManifold1Temperature() {}

    IntakeManifold1Temperature(String Temperature, String UnitOfMeasure, String datetime) {
        this.Temperature = Temperature;
        this.UnitOfMeasure = UnitOfMeasure;
        this.datetime = datetime;
    }
}
