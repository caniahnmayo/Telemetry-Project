package org.acme.fleet.equipment.engine;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class EngineIdleFuelUsed {

    public String Fuel;
    public String UnitOfMeasure;
    public String datetime;

    EngineIdleFuelUsed() {}

    EngineIdleFuelUsed(String Fuel, String UnitOfMeasure, String datetime) {
        this.Fuel = Fuel;
        this.UnitOfMeasure = UnitOfMeasure;
        this.datetime = datetime;
    }
}
