package org.acme.fleet.equipment;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class ParameterChanged {

    @com.fasterxml.jackson.annotation.JsonProperty("Ground Mode")
    public String GroundMode;

    @com.fasterxml.jackson.annotation.JsonProperty("Platform Mode")
    public String PlatformMode;

    ParameterChanged() {}

    ParameterChanged(String GroundMode, String PlatformMode) {
        this.GroundMode = GroundMode;
        this.PlatformMode = PlatformMode;
    }
}
