package org.acme.fleet.equipment.machine;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class PlatformModeSelected {

    public String Value;
    public String datetime;

    PlatformModeSelected() {}

    public PlatformModeSelected(String Value, String datetime) {
        this.Value = Value;
        this.datetime = datetime;
    }
}
