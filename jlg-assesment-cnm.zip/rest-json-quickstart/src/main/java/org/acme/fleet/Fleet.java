package org.acme.fleet;

import org.acme.fleet.equipment.FuelLevel;

import java.time.OffsetDateTime;
import java.util.*;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class Fleet {

    public String snapshotTime;
    public List<Equipment> Equipment;
    public PageInfo PageInfo;

    Fleet() {}

    public Fleet(String snapshotTime, List<Equipment> Equipment, PageInfo PageInfo) {
        this.snapshotTime = snapshotTime;
        this.Equipment = Equipment;
        this.PageInfo = PageInfo;
    }

    public double getAvgFuelLevel() {

        if(Equipment.isEmpty()) return -1;

        double count = 0.0;
        double sum = 0.0;
        for(Equipment equipment : this.Equipment) {
            if (equipment.FuelLevel != null) {
                if (equipment.FuelLevel.FuelLevel != null && !equipment.FuelLevel.FuelLevel.isEmpty()) {
                    count++;
                    sum += Double.parseDouble(FuelLevel.commonize(equipment.FuelLevel.FuelLevel));
                }
            }
        }

        if(sum == 0) return -1;

        return sum / count;
    }

    public double getAvgBatteryV() {

        if(Equipment.isEmpty()) return -1;

        double count = 0.0;
        double sum = 0.0;
        for(Equipment equipment : this.Equipment) {
            if (equipment.BatteryVoltage != null) {
                if (equipment.BatteryVoltage.BatteryReading != null && !equipment.BatteryVoltage.BatteryReading.isEmpty()) {
                    count++;
                    sum += Double.parseDouble(equipment.BatteryVoltage.BatteryReading);
                }
            }
        }

        if(sum == 0) return -1;

        return sum / count;
    }

    public int getFleetSize() {
        int count = 0;
        Set<String> set = new HashSet<>();
        for(Equipment equipment : this.Equipment) {
            if (equipment.EquipmentHeader != null) {
                if (equipment.EquipmentHeader.EquipmentID != null) {
                    set.add(equipment.EquipmentHeader.EquipmentID);
                }
            }
        }
        for(String equipmentID : set) {
            count++;
        }
        return count;
    }

    public OffsetDateTime getOldestMachine(){
        Set<String> set = new HashSet<>();
        for(Equipment equipment : this.Equipment) {
            if (equipment.EquipmentHeader != null) {
                if (equipment.EquipmentHeader.UnitInstallDateTime != null && !equipment.EquipmentHeader.UnitInstallDateTime.isEmpty()) {
                    set.add(equipment.EquipmentHeader.UnitInstallDateTime);
                }
            }
        }

        List<OffsetDateTime> dates = new ArrayList<>();
        for(String date : set) {
            dates.add(OffsetDateTime.parse(date));
        }

        OffsetDateTime currentOldest = OffsetDateTime.now();
        for(OffsetDateTime date : dates) {
            if(date.isBefore(currentOldest)) {
                currentOldest = date;
            }
        }
        return currentOldest;
    }
}
