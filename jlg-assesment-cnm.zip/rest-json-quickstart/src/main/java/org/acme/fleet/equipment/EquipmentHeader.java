package org.acme.fleet.equipment;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class EquipmentHeader {

    public String CompanyName;
    public String CustomerNumber;
    public String EngineOrBatteryTier;
    public String EquipmentID;
    public String Model;
    public String ModelType;
    public String OEMName;
    public String SerialNumber;
    public String TerminalID;
    public String UnitInstallDateTime;
    public String Year;
    public String messageType;

    EquipmentHeader() {}

    public EquipmentHeader(
            String CompanyName,
            String CustomerNumber,
            String EngineOrBatteryTier,
            String EquipmentID,
            String Model,
            String ModelType,
            String OEMName,
            String SerialNumber,
            String TerminalID,
            String UnitInstallDateTime,
            String Year,
            String messageType
    ) {
        this.CompanyName = CompanyName;
        this.CustomerNumber = CustomerNumber;
        this.EngineOrBatteryTier = EngineOrBatteryTier;
        this.EquipmentID = EquipmentID;
        this.Model = Model;
        this.ModelType = ModelType;
        this.OEMName = OEMName;
        this.SerialNumber = SerialNumber;
        this.TerminalID = TerminalID;
        this.UnitInstallDateTime = UnitInstallDateTime;
        this.Year = Year;
        this.messageType = messageType;
    }
}
