package org.acme.fleet.equipment.engine;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class TurboIntakePress {

    public String Torque;
    public String UnitOfMeasure;
    public String datetime;

    TurboIntakePress() {}

    TurboIntakePress(String Torque, String UnitOfMeasure, String datetime) {
        this.Torque = Torque;
        this.UnitOfMeasure = UnitOfMeasure;
        this.datetime = datetime;
    }
}
