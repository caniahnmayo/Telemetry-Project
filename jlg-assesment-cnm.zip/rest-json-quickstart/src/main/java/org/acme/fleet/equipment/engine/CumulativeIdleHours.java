package org.acme.fleet.equipment.engine;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class CumulativeIdleHours {

    public String Hour;
    public String datetime;

    CumulativeIdleHours(){}

    CumulativeIdleHours(String hour, String datetime) {
        this.Hour=hour;
        this.datetime=datetime;
    }
}
