package org.acme.fleet.equipment;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class StateOfCharge {

    public String Percent;
    public String datetime;

    StateOfCharge() {}

    StateOfCharge(String Percent, String datetime) {
        this.Percent = Percent;
        this.datetime = datetime;
    }
}
