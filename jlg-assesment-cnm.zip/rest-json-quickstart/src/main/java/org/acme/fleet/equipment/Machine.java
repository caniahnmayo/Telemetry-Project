package org.acme.fleet.equipment;

import org.acme.fleet.equipment.machine.GroundModeSelected;
import org.acme.fleet.equipment.machine.PlatformHeight;
import org.acme.fleet.equipment.machine.PlatformModeSelected;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class Machine {

    public GroundModeSelected GroundModeSelected;
    public PlatformHeight PlatformHeight;
    public PlatformModeSelected PlatformModeSelected;

    Machine() {}

    Machine(
            GroundModeSelected GroundModeSelected,
            PlatformHeight PlatformHeight,
            PlatformModeSelected PlatformModeSelected
    ) {
        this.GroundModeSelected = GroundModeSelected;
        this.PlatformHeight = PlatformHeight;
        this.PlatformModeSelected = PlatformModeSelected;
    }
}
