package org.acme.fleet.equipment.engine;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class FuelConsumptionRate {

    String ConsumptionRate;
    String UnitOfMeasure;
    String datetime;

    FuelConsumptionRate() {}

    FuelConsumptionRate(String consumptionRate, String unitOfMeasure, String datetime) {
        this.ConsumptionRate = consumptionRate;
        this.UnitOfMeasure = unitOfMeasure;
        this.datetime = datetime;
    }
}
