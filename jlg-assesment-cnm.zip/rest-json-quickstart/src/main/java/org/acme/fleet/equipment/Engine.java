package org.acme.fleet.equipment;

import org.acme.fleet.equipment.engine.*;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class Engine {

    public ActualTorque ActualTorque;
    public BarometricPressure BarometricPressure;
    public CoolantTemp CoolantTemp;
    public CumulativeIdleHours CumulativeIdleHours;
    public EngineIdleFuelUsed EngineIdleFuelUsed;
    public EngineLoad EngineLoad;
    public EngineSpeed EngineSpeed;
    public FuelConsumptionRate FuelConsumptionRate;
    public FuelDeliveryPressure FuelDeliveryPressure;
    public FuelUsed FuelUsed;
    public IntakeManifold1Pressure IntakeManifold1Pressure;
    public IntakeManifold1Temperature IntakeManifold1Temperature;
    public OilPressure OilPressure;
    public RequestedSpeedLimit RequestedSpeedLimit;
    public RequestedTorque RequestedTorque;
    public TurboIntakePress TurboIntakePress;
    public TurboIntakeTemp TurboIntakeTemp;

    Engine() {}

    Engine(
            ActualTorque ActualTorque,
            BarometricPressure BarometricPressure,
            CoolantTemp CoolantTemp,
            CumulativeIdleHours CumulativeIdleHours,
            EngineIdleFuelUsed EngineIdleFuelUsed,
            EngineLoad EngineLoad,
            EngineSpeed EngineSpeed,
            FuelConsumptionRate FuelConsumptionRate,
            FuelDeliveryPressure FuelDeliveryPressure,
            FuelUsed FuelUsed,
            IntakeManifold1Pressure IntakeManifold1Pressure,
            IntakeManifold1Temperature IntakeManifold1Temperature,
            OilPressure OilPressure,
            RequestedSpeedLimit RequestedSpeedLimit,
            RequestedTorque RequestedTorque,
            TurboIntakePress TurboIntakePress,
            TurboIntakeTemp TurboIntakeTemp
    ) {
        this.ActualTorque = ActualTorque;
        this.BarometricPressure = BarometricPressure;
        this.CoolantTemp = CoolantTemp;
        this.CumulativeIdleHours = CumulativeIdleHours;
        this.EngineIdleFuelUsed = EngineIdleFuelUsed;
        this.EngineLoad = EngineLoad;
        this.EngineSpeed = EngineSpeed;
        this.FuelConsumptionRate = FuelConsumptionRate;
        this.FuelUsed = FuelUsed;
        this.IntakeManifold1Pressure = IntakeManifold1Pressure;
        this.IntakeManifold1Temperature = IntakeManifold1Temperature;
        this.OilPressure = OilPressure;
        this.RequestedSpeedLimit = RequestedSpeedLimit;
        this.RequestedTorque = RequestedTorque;
        this.TurboIntakePress = TurboIntakePress;
        this.TurboIntakeTemp = TurboIntakeTemp;
    }
}
