package org.acme.fleet.equipment;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class FuelLevel {

    public String FuelLevel;
    public String datetime;

    public FuelLevel() {}
    public FuelLevel(String FuelLevel, String datetime)
    {
        this.FuelLevel = commonize(FuelLevel);
        this.datetime = datetime;
    }

    public static String commonize(String FuelLevel) {
        if (FuelLevel != null) {
            switch (FuelLevel.toLowerCase()) {
                case "error", "empty": {
                    return "0";
                }
                case "full": {
                    return "100";
                }
                case "high", "high-level": {
                    return "80";
                }
                case "low", "low-level": {
                    return "20";
                }
                case "medium", "mid-level", "mid": {
                    return "50";
                }
                default: {
                    if (FuelLevel.contains("/")) {
                        String[] FuelLevelArray = FuelLevel.split("/");
                        double FuelLevelValue = Double.parseDouble(FuelLevelArray[0]) / Double.parseDouble(FuelLevelArray[1]);
                        return String.valueOf(FuelLevelValue);
                    } else {
                        return FuelLevel;
                    }
                }
            }
        }

        return FuelLevel;
    }
}
