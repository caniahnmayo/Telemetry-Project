package org.acme.fleet.equipment.engine;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class EngineSpeed {

    public String Speed;
    public String UnitOfMeasure;
    public String datetime;

    EngineSpeed() {}

    EngineSpeed(String speed, String unitOfMeasure, String datetime) {
        this.Speed = speed;
        this.UnitOfMeasure = unitOfMeasure;
        this.datetime = datetime;
    }
}
