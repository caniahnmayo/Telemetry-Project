package org.acme.fleet.equipment;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class DeviceBattery {

    public String BatteryReading;
    public String UnitOfMeasure;
    public String datetime;

    DeviceBattery() {}

    DeviceBattery(String BatteryReading, String UnitOfMeasure, String datetime) {
        this.BatteryReading = BatteryReading;
        this.UnitOfMeasure = UnitOfMeasure;
        this.datetime = datetime;
    }

}
