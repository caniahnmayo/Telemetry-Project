package org.acme.fleet.equipment;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class DiagnosticTroubleCode {

    public String CodeDescription;
    public String CodeIdentifier;
    public String CodeSeverity;
    public String CodeSource;
    public String FmiCode;
    public String Frequency;
    public String Status;
    public String dateTime;

    DiagnosticTroubleCode() {}

    DiagnosticTroubleCode(
            String CodeDescription,
            String CodeIdentifier,
            String CodeSeverity,
            String CodeSource,
            String FmiCode,
            String Frequency,
            String Status,
            String dateTime
    ){
        this.CodeDescription = CodeDescription;
        this.CodeIdentifier = CodeIdentifier;
        this.CodeSeverity = CodeSeverity;
        this.CodeSource = CodeSource;
        this.FmiCode = FmiCode;
        this.Frequency = Frequency;
        this.Status = Status;
        this.dateTime = dateTime;
    }
}
