package org.acme.fleet.equipment.engine;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class EngineLoad {

    public String Percent;
    public String datetime;

    EngineLoad() {}

    EngineLoad(String datetime, String Percent) {
        this.datetime = datetime;
        this.Percent = Percent;
    }
}
