package org.acme.fleet.equipment.engine;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class BarometricPressure {

    public String Pressure;
    public String UnitOfMeasure;
    public String datetime;

    BarometricPressure() {}

    BarometricPressure(String Pressure, String UnitOfMeasure, String datetime) {
        this.Pressure = Pressure;
        this.UnitOfMeasure = UnitOfMeasure;
        this.datetime = datetime;
    }
}
