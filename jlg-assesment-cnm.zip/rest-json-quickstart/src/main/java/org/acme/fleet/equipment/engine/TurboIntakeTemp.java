package org.acme.fleet.equipment.engine;

@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class TurboIntakeTemp {

    public String Temperature;
    public String UnitOfMeasure;
    public String datetime;

    TurboIntakeTemp() {}

    TurboIntakeTemp(String Temperature, String UnitOfMeasure, String datetime) {
        this.Temperature = Temperature;
        this.UnitOfMeasure = UnitOfMeasure;
        this.datetime = datetime;
    }
}
